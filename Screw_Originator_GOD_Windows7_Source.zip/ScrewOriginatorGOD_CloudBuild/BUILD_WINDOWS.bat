@echo off
setlocal
echo SCREW ORIGINATOR G.O.D - Windows build helper
where cmake >nul 2>nul
if errorlevel 1 (
  echo ERROR: CMake not found. Install CMake and Visual Studio C++ tools.
  pause
  exit /b 1
)
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -A x64
if errorlevel 1 goto failed
cmake --build build --config Release
if errorlevel 1 goto failed
echo Build finished. Search build folder for ScrewOriginatorGOD.vst3
pause
exit /b 0
:failed
echo Build failed. Check network access, CMake and Visual Studio C++ tools.
pause
exit /b 1
