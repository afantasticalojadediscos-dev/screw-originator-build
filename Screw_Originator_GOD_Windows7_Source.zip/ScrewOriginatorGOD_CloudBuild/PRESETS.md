# Factory preset starting points

| Preset | Speed | Drive | Low-pass | Chop division | Chop amount | Echo | Wow |
|---|---:|---:|---:|---:|---:|---:|---:|
| DJ Screw Classic | 0.72 | 0.16 | 8500 Hz | 4 | 0.35 | 0.18 | 0.22 |
| Purple Drank | 0.62 | 0.35 | 6200 Hz | 8 | 0.48 | 0.25 | 0.35 |
| Houston Night | 0.78 | 0.22 | 10500 Hz | 4 | 0.24 | 0.15 | 0.18 |
| Heavy Slowed | 0.52 | 0.20 | 7200 Hz | 2 | 0.15 | 0.20 | 0.30 |
| Chopped Vocals | 0.76 | 0.10 | 12000 Hz | 8 | 0.72 | 0.08 | 0.10 |
| Tape Underground | 0.68 | 0.42 | 5000 Hz | 4 | 0.42 | 0.32 | 0.55 |

Values are prototype defaults, not measured emulations of any specific record or DJ Screw setup.
