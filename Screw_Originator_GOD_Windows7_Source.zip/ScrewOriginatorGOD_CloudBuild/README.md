# SCREW ORIGINATOR G.O.D — VST3 source project

A JUCE/CMake starter plugin for FL Studio 24 on Windows 10/11. It includes a dark purple interface, six factory presets, vinyl/tape colour controls, beat-synchronised chop gating, echo, low-pass filtering and drive.

## Important audio-engine note

This is a **compilable starter / prototype**, not a finished commercial-grade vinyl slowdown algorithm. The `Vinyl Speed` parameter currently changes the delay used by the tape-colour stage and the preset's slow-vinyl character; it does **not** change the FL Studio project's tempo or perform full-quality varispeed playback of an entire song. A conventional insert-effect VST cannot independently slow the host timeline. For true DJ Screw-style whole-track slowdown, put the audio in a Sampler/Audio Clip and use FL Studio's time-stretching mode (Resample) or build a dedicated file/sample player into a later plugin version.

The chop gate is tempo-aware when the host provides BPM/PPQ transport data. Manual chopping as physical trigger buttons is not included in this first code drop; the Chop Amount and Chop Division controls give a simple always-on rhythmic chop. This is an honest MVP baseline to extend and test.

## Requirements

- Windows 7 SP1 / Windows 10 / Windows 11, 64-bit (Windows 7 is a legacy target and requires the older toolchain below)
- Visual Studio 2019 with **Desktop development with C++** for the Windows 7 build (VS 2022 is recommended only for Windows 10/11)
- CMake (Visual Studio installer can provide it)
- JUCE 6.1.6 source checkout for the Windows 7 target; JUCE 7/8 may require newer Windows versions
- FL Studio 24 64-bit

## Build with CMake (Windows helper included)

You can run `BUILD_WINDOWS.bat` from the project folder after installing Visual Studio C++ tools and JUCE. Set the `JUCE_DIR` environment variable first, for example `set JUCE_DIR=C:\\JUCE\\lib\\cmake\\JUCE`.



1. Download JUCE from https://juce.com/get-juce/ and extract it somewhere such as `C:/JUCE`.
2. Open **x64 Native Tools Command Prompt for VS 2022**.
3. Change directory to this project folder.
4. Configure (adjust paths to your own folders):

   ```bat
   cmake -S . -B build -DJUCE_DIR=C:/JUCE/lib/cmake/JUCE -DCMAKE_BUILD_TYPE=Release -A x64
   ```

   If your JUCE checkout does not expose that CMake package path, use JUCE's installed CMake package or add JUCE as a subdirectory in CMakeLists.txt. JUCE's package location differs between distributions.
5. Compile:

   ```bat
   cmake --build build --config Release
   ```

6. Find `ScrewOriginatorGOD.vst3` under the build tree (commonly `build/ScrewOriginatorGOD_artefacts/Release/VST3/`).
7. Copy the **whole `ScrewOriginatorGOD.vst3` bundle folder** to:
   - Per-user: `%LOCALAPPDATA%\\Programs\\Common\\VST3\\`
   - Or system-wide: `C:\\Program Files\\Common Files\\VST3\\`

   Create the destination folder if needed. Do not put only the files inside the bundle; copy the `.vst3` folder itself.
8. Open FL Studio 24 → **Options → Manage plugins** → **Find installed plugins**. If needed, add the VST3 folder in Plugin search paths and scan again.
9. Load **SCREW ORIGINATOR G.O.D** from the plugin database on a Mixer insert.

## Quick-start settings

- DJ Screw Classic: start with Speed 0.72, Chop Amount around 0.35.
- Heavy Slowed: lower speed preset, subtle echo, low-pass.
- Chopped Vocals: increase Chop Amount and try Chop Division 8.
- Keep the Wet control below 100% if you want some original transient clarity.

## Current limitations / next development pass

- The audio processor is a proof-of-concept and needs compilation plus audio QA in FL Studio.
- The speed control is not true tape-varispeed; this needs a dedicated resampling/sample-player architecture for reliable slowdown without buffer drift.
- “Manual chop” buttons, waveform display, undo/randomize and saveable user preset bank are planned but not implemented in this source version.
- Factory presets are available through the plug-in's program selector; changing presets in the UI updates parameters.
- No installer is included. Build and install locally using the steps above.

## Copyright / branding

This is an original homage to the general Chopped & Screwed production technique. It is not affiliated with DJ Screw's estate and does not include copyrighted samples.


## Delivery status

This download is the renamed C++ source project and Windows build helper, **not a precompiled VST3 binary**. The current execution environment is Linux and does not have JUCE installed or a Windows VST3 build toolchain, so a Windows VST3 binary could not be compiled and verified here. Do not rename the ZIP to `.vst3`; FL Studio needs the compiled VST3 bundle.


## Windows 7 compatibility notes (important)

This source was adjusted to avoid JUCE 7/8-only `FontOptions` usage and to use the JUCE 6 playhead API when `JUCE_MAJOR_VERSION < 7`. For a Windows 7 target, use Windows 7 SP1 64-bit, Visual Studio 2019 (v142), and JUCE 6.1.6. Newer JUCE releases and current toolchains may no longer support Windows 7. Install the required Microsoft Visual C++ runtime on the target PC if prompted.

A successful build on a modern computer does not prove Windows 7 runtime compatibility. The VST3 bundle must be built with the legacy toolchain and tested on an actual Windows 7 SP1 machine and in the user's FL Studio version. This package has not been compiled or run in a Windows environment here.

## Test status

Static source/package checks only. This environment has CMake and a Linux C++ compiler, but no JUCE installation, no Windows compiler, and no Windows 7 runtime. Therefore it is not possible to claim a successful Windows VST3 build or Windows 7 host test. The existing audio engine remains a prototype: the speed control is not true full-track varispeed and manual chop trigger buttons are not implemented.


## Cloud build from Android tablet (GitHub Actions)

A GitHub Actions workflow can compile the source on a hosted Windows runner and expose the result as a downloadable artifact. The hosted runner uses a modern Windows image; it does not certify Windows 7 runtime compatibility. Use the workflow instructions provided separately in this package/conversation.
