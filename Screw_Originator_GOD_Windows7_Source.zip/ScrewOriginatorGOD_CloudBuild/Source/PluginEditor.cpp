#include "PluginEditor.h"

ScrewOriginatorGODAudioProcessorEditor::ScrewOriginatorGODAudioProcessorEditor (ScrewOriginatorGODAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    setSize(620, 430);
    title.setText("SCREW ORIGINATOR G.O.D", juce::dontSendNotification);
    title.setFont(juce::Font(26.0f, juce::Font::bold));
    title.setColour(juce::Label::textColourId, juce::Colour(0xffeadbff));
    addAndMakeVisible(title);
    subtitle.setText("CHOPPED • SCREWED • HOUSTON TAPE DECK", juce::dontSendNotification);
    subtitle.setFont(juce::Font(11.0f));
    subtitle.setColour(juce::Label::textColourId, juce::Colour(0xffb7a1d2));
    addAndMakeVisible(subtitle);

    presetBox.addItem("DJ Screw Classic", 1);
    presetBox.addItem("Purple Drank", 2);
    presetBox.addItem("Houston Night", 3);
    presetBox.addItem("Heavy Slowed", 4);
    presetBox.addItem("Chopped Vocals", 5);
    presetBox.addItem("Tape Underground", 6);
    presetBox.setSelectedId(1);
    presetBox.onChange = [this] { processor.setCurrentProgram(presetBox.getSelectedId() - 1); };
    addAndMakeVisible(presetBox);

    setupSlider(speed, speedLabel, "Vinyl Speed", "SPEED");
    setupSlider(drive, driveLabel, "Tape Drive", "DRIVE");
    setupSlider(lowpass, lowpassLabel, "Low-pass", "LOWPASS");
    setupSlider(wet, wetLabel, "Wet / Dry", "WET");
    setupSlider(chopRate, chopRateLabel, "Chop Division", "CHOPRATE");
    setupSlider(chopAmount, chopAmountLabel, "Chop Amount", "CHOPMIX");
    setupSlider(echo, echoLabel, "Echo", "ECHO");
    setupSlider(wow, wowLabel, "Tape Wow", "WOW");
}

void ScrewOriginatorGODAudioProcessorEditor::setupSlider(juce::Slider& s, juce::Label& l,
                                                      const juce::String& name, const juce::String& id)
{
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 72, 20);
    s.setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xffbb7bff));
    s.setColour(juce::Slider::thumbColourId, juce::Colour(0xfff1e5ff));
    l.setText(name, juce::dontSendNotification);
    l.setJustificationType(juce::Justification::centred);
    l.setColour(juce::Label::textColourId, juce::Colour(0xffe6d9f5));
    addAndMakeVisible(s); addAndMakeVisible(l);
    attachments.push_back(std::make_unique<SliderAttachment>(processor.parameters, id, s));
}

void ScrewOriginatorGODAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff100b18));
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff2b173d), 0, 0,
                                          juce::Colour(0xff100b18), 620, 430, false));
    g.fillRoundedRectangle(getLocalBounds().toFloat().reduced(5), 14.0f);
    g.setColour(juce::Colour(0xff69458c));
    g.drawRoundedRectangle(getLocalBounds().toFloat().reduced(5), 14.0f, 1.5f);
    g.setColour(juce::Colour(0xff6b4b8c));
    g.drawLine(20.0f, 82.0f, 600.0f, 82.0f, 1.0f);
    g.setColour(juce::Colour(0xffc8a2ff));
    g.setFont(12.0f);
    g.drawText("SLOW IT DOWN. CHOP IT UP.", 22, 395, 575, 20, juce::Justification::centred);
}

void ScrewOriginatorGODAudioProcessorEditor::resized()
{
    title.setBounds(20, 12, 350, 38);
    subtitle.setBounds(22, 48, 350, 22);
    presetBox.setBounds(400, 30, 190, 30);
    const int left = 20, top = 100, cellW = 145, cellH = 135, gapX = 8;
    juce::Slider* sliders[] = { &speed, &drive, &lowpass, &wet, &chopRate, &chopAmount, &echo, &wow };
    juce::Label* labels[] = { &speedLabel, &driveLabel, &lowpassLabel, &wetLabel, &chopRateLabel, &chopAmountLabel, &echoLabel, &wowLabel };
    for (int i = 0; i < 8; ++i)
    {
        int col = i % 4, row = i / 4;
        int x = left + col * (cellW + gapX), y = top + row * cellH;
        labels[i]->setBounds(x, y, cellW, 24);
        sliders[i]->setBounds(x + 8, y + 22, cellW - 16, 105);
    }
}
