#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class ScrewOriginatorGODAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit ScrewOriginatorGODAudioProcessorEditor (ScrewOriginatorGODAudioProcessor&);
    ~ScrewOriginatorGODAudioProcessorEditor() override = default;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    ScrewOriginatorGODAudioProcessor& processor;
    juce::ComboBox presetBox;
    juce::Label title, subtitle;
    juce::Slider speed, drive, lowpass, chopRate, chopAmount, echo, wow, wet;
    juce::Label speedLabel, driveLabel, lowpassLabel, chopRateLabel, chopAmountLabel, echoLabel, wowLabel, wetLabel;
    std::vector<std::unique_ptr<SliderAttachment>> attachments;
    void setupSlider(juce::Slider&, juce::Label&, const juce::String&, const juce::String&);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ScrewOriginatorGODAudioProcessorEditor)
};
