#include "PluginProcessor.h"
#include "PluginEditor.h"

ScrewOriginatorGODAudioProcessor::ScrewOriginatorGODAudioProcessor()
    : AudioProcessor (BusesProperties()
        .withInput ("Input", juce::AudioChannelSet::stereo(), true)
        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      parameters (*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout ScrewOriginatorGODAudioProcessor::createParameterLayout()
{
    using namespace juce;
    AudioProcessorValueTreeState::ParameterLayout p;
    p.add (std::make_unique<AudioParameterFloat>("SPEED", "Vinyl Speed",
        NormalisableRange<float>(0.50f, 1.00f, 0.01f), 0.78f));
    p.add (std::make_unique<AudioParameterFloat>("DRIVE", "Tape Drive",
        NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.18f));
    p.add (std::make_unique<AudioParameterFloat>("LOWPASS", "Low-pass",
        NormalisableRange<float>(800.0f, 20000.0f, 1.0f, 0.35f), 9500.0f));
    p.add (std::make_unique<AudioParameterFloat>("WET", "Wet",
        NormalisableRange<float>(0.0f, 1.0f, 0.01f), 1.0f));
    p.add (std::make_unique<AudioParameterFloat>("CHOPRATE", "Chop Division",
        NormalisableRange<float>(1.0f, 16.0f, 1.0f), 4.0f));
    p.add (std::make_unique<AudioParameterFloat>("CHOPMIX", "Chop Amount",
        NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.0f));
    p.add (std::make_unique<AudioParameterFloat>("ECHO", "Echo Amount",
        NormalisableRange<float>(0.0f, 0.7f, 0.01f), 0.12f));
    p.add (std::make_unique<AudioParameterFloat>("WOW", "Tape Wow",
        NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.12f));
    return p;
}

void ScrewOriginatorGODAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    sr = sampleRate;
    delayBuffer.setSize (getTotalNumOutputChannels(), (int) (sr * 2.0) + samplesPerBlock + 8);
    delayBuffer.clear();
    writePos = 0;
    chopPhase = 0.0f;
    envelope = 1.0f;
}

void ScrewOriginatorGODAudioProcessor::releaseResources() {}

bool ScrewOriginatorGODAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    return in == out && (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo());
}

void ScrewOriginatorGODAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int channels = juce::jmin(buffer.getNumChannels(), delayBuffer.getNumChannels());
    const int n = buffer.getNumSamples();

    auto* speedP = parameters.getRawParameterValue("SPEED");
    auto* driveP = parameters.getRawParameterValue("DRIVE");
    auto* lpP = parameters.getRawParameterValue("LOWPASS");
    auto* wetP = parameters.getRawParameterValue("WET");
    auto* rateP = parameters.getRawParameterValue("CHOPRATE");
    auto* chopP = parameters.getRawParameterValue("CHOPMIX");
    auto* echoP = parameters.getRawParameterValue("ECHO");
    auto* wowP = parameters.getRawParameterValue("WOW");

    const float speed = speedP->load();
    const float drive = driveP->load();
    const float cutoff = lpP->load();
    const float wet = wetP->load();
    const float chopMix = chopP->load();
    const float echo = echoP->load();
    const float wow = wowP->load();
    const float chopDivision = rateP->load();

    double bpm = 90.0;
    double ppq = 0.0;
    bool playing = false;
    if (auto* ph = getPlayHead())
    {
#if JUCE_MAJOR_VERSION >= 7
        if (auto pos = ph->getPosition())
        {
            bpm = pos->getBpm().orFallback(90.0);
            ppq = pos->getPpqPosition().orFallback(0.0);
            playing = pos->getIsPlaying();
        }
#else
        juce::AudioPlayHead::CurrentPositionInfo pos;
        if (ph->getCurrentPosition(pos))
        {
            if (pos.bpm > 0.0) bpm = pos.bpm;
            ppq = pos.ppqPosition;
            playing = pos.isPlaying;
        }
#endif
    }

    const float samplesPerQuarter = (float) (sr * 60.0 / juce::jmax(1.0, bpm));
    const float chopPeriod = juce::jmax(1.0f, samplesPerQuarter * 4.0f / chopDivision);
    const float lpCoeff = 1.0f - std::exp(-2.0f * juce::MathConstants<float>::pi * cutoff / (float) sr);
    const int maxDelay = delayBuffer.getNumSamples();
    const int delaySamples = juce::jlimit(1, maxDelay - 1, (int) (sr * 0.22 / juce::jmax(0.5f, speed)));
    static thread_local std::vector<float> filterState(2, 0.0f);
    static thread_local std::vector<float> echoState(2, 0.0f);

    for (int i = 0; i < n; ++i)
    {
        // Beat-synchronised chop. The phase resets at each host block from PPQ when playing.
        float phase = chopPhase;
        if (playing)
        {
            const double beatPhase = ppq + (double) i / samplesPerQuarter;
            phase = (float) std::fmod(std::max(0.0, beatPhase * 4.0 / chopDivision), 1.0);
        }
        const bool gateOn = phase < 0.70f;
        const float gate = 1.0f - chopMix + chopMix * (gateOn ? 1.0f : 0.0f);

        for (int ch = 0; ch < channels; ++ch)
        {
            float dry = buffer.getSample(ch, i);
            delayBuffer.setSample(ch, writePos, dry);
            int readPos = writePos - delaySamples;
            while (readPos < 0) readPos += maxDelay;
            float tape = delayBuffer.getSample(ch, readPos);

            // Pitch-down/slow-vinyl colour approximation: darkening, saturation, wow and echo.
            float wowMod = 1.0f + wow * 0.003f * std::sin((float) (juce::MathConstants<double>::twoPi * (0.25 + ch * 0.03) * (writePos / sr)));
            tape *= wowMod;
            const int stateIndex = juce::jmin(ch, (int) filterState.size() - 1);
            filterState[(size_t) stateIndex] += lpCoeff * (tape - filterState[(size_t) stateIndex]);
            float effected = filterState[(size_t) stateIndex];
            const float gain = 1.0f + drive * 8.0f;
            effected = std::tanh(effected * gain) / std::tanh(gain);
            effected += echo * echoState[(size_t) stateIndex];
            echoState[(size_t) stateIndex] = effected * 0.48f;
            effected *= gate;

            buffer.setSample(ch, i, dry * (1.0f - wet) + effected * wet);
        }
        writePos = (writePos + 1) % maxDelay;
        chopPhase += 1.0f / chopPeriod;
        if (chopPhase >= 1.0f) chopPhase -= 1.0f;
    }
}

void ScrewOriginatorGODAudioProcessor::setCurrentProgram (int index)
{
    currentProgram = juce::jlimit(0, 5, index);
    loadPreset(currentProgram);
}

const juce::String ScrewOriginatorGODAudioProcessor::getProgramName (int index)
{
    const juce::StringArray names { "DJ Screw Classic", "Purple Drank", "Houston Night",
        "Heavy Slowed", "Chopped Vocals", "Tape Underground" };
    return names[juce::jlimit(0, names.size() - 1, index)];
}

void ScrewOriginatorGODAudioProcessor::loadPreset (int index)
{
    struct Values { float speed, drive, lp, wet, rate, chop, echo, wow; };
    const Values presets[] = {
        {0.72f, 0.16f, 8500.0f, 1.0f, 4.0f, 0.35f, 0.18f, 0.22f},
        {0.62f, 0.35f, 6200.0f, 1.0f, 8.0f, 0.48f, 0.25f, 0.35f},
        {0.78f, 0.22f, 10500.0f, 1.0f, 4.0f, 0.24f, 0.15f, 0.18f},
        {0.52f, 0.20f, 7200.0f, 1.0f, 2.0f, 0.15f, 0.20f, 0.30f},
        {0.76f, 0.10f, 12000.0f, 1.0f, 8.0f, 0.72f, 0.08f, 0.10f},
        {0.68f, 0.42f, 5000.0f, 1.0f, 4.0f, 0.42f, 0.32f, 0.55f}
    };
    const auto v = presets[juce::jlimit(0, 5, index)];
    auto set = [this](const char* id, float value)
    {
        if (auto* p = parameters.getParameter(id))
            p->setValueNotifyingHost(p->convertTo0to1(value));
    };
    set("SPEED", v.speed); set("DRIVE", v.drive); set("LOWPASS", v.lp);
    set("WET", v.wet); set("CHOPRATE", v.rate); set("CHOPMIX", v.chop);
    set("ECHO", v.echo); set("WOW", v.wow);
}

void ScrewOriginatorGODAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary(*xml, destData);
}

void ScrewOriginatorGODAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary(data, sizeInBytes));
    if (xml != nullptr && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ScrewOriginatorGODAudioProcessor();
}
