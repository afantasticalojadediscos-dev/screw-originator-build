#pragma once
#include <JuceHeader.h>

class ScrewOriginatorGODAudioProcessor : public juce::AudioProcessor
{
public:
    ScrewOriginatorGODAudioProcessor();
    ~ScrewOriginatorGODAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 2.0; }
    int getNumPrograms() override { return 6; }
    int getCurrentProgram() override { return currentProgram; }
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState parameters;
    void loadPreset (int index);

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    int currentProgram = 0;
    double sr = 44100.0;
    juce::AudioBuffer<float> delayBuffer;
    int writePos = 0;
    float chopPhase = 0.0f;
    float envelope = 1.0f;
    juce::Random random;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ScrewOriginatorGODAudioProcessor)
};
